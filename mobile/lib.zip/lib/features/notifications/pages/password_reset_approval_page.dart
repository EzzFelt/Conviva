import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/app_sizes.dart';
import '../../../core/services/elder_recovery_request_service.dart';
import '../../../shared/widgets/button_widget.dart';
import '../../auth/models/elder_recovery_request.dart';

class PasswordResetApprovalPage extends StatefulWidget {
  const PasswordResetApprovalPage({super.key, required this.requestId});

  final String requestId;

  @override
  State<PasswordResetApprovalPage> createState() =>
      _PasswordResetApprovalPageState();
}

class _PasswordResetApprovalPageState extends State<PasswordResetApprovalPage> {
  bool _isResponding = false;
  bool _isForwarding = false;

  Future<void> _respond(bool approve) async {
    if (_isResponding) return;
    setState(() => _isResponding = true);

    try {
      await ElderRecoveryRequestService.instance.respond(
        requestId: widget.requestId,
        approve: approve,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            approve
                ? 'A troca de senha foi aprovada.'
                : 'A solicitação foi recusada.',
          ),
        ),
      );
      context.pop();
    } catch (error) {
      if (!mounted) return;
      final message = error is StateError
          ? error.message.toString()
          : 'Não foi possível responder à solicitação. Tente novamente.';
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } finally {
      if (mounted) setState(() => _isResponding = false);
    }
  }

  Future<void> _forwardLink() async {
    if (_isForwarding) return;
    setState(() => _isForwarding = true);

    try {
      await ElderRecoveryRequestService.instance.forwardResetLinkToElder(
        widget.requestId,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link encaminhado ao idoso.')),
      );
    } catch (error) {
      if (!mounted) return;
      final message = error is StateError
          ? error.message.toString()
          : 'Não foi possível encaminhar o link. Tente novamente.';
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } finally {
      if (mounted) setState(() => _isForwarding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final sizes = context.appSizes;

    return Scaffold(
      appBar: AppBar(title: const Text('Pedido de troca de senha')),
      body: StreamBuilder<ElderRecoveryRequest>(
        stream: ElderRecoveryRequestService.instance.watchApprovalRequest(
          widget.requestId,
        ),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return Center(
              child: Padding(
                padding: EdgeInsets.all(sizes.lg),
                child: Text(
                  'Não foi possível carregar este pedido. Ele pode ter '
                  'expirado, já ter sido respondido ou não pertencer à sua conta.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyLarge,
                ),
              ),
            );
          }

          final request = snapshot.data!;
          final isPending = request.status == 'pending' && !request.isExpired;
          final isApprover =
              FirebaseAuth.instance.currentUser?.uid == request.approvedByUid;
          final statusMessage = switch (request.status) {
            'approved' => 'Este pedido já foi aprovado.',
            'rejected' => 'Este pedido já foi recusado.',
            'completed' => 'A equipe de suporte já concluiu este pedido.',
            _ when request.isExpired => 'Este pedido expirou após 24 horas.',
            _ => 'A primeira resposta de um dos responsáveis encerra o pedido.',
          };

          return Padding(
            padding: EdgeInsets.all(sizes.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${request.elderName ?? 'O idoso'} pediu para redefinir '
                  'a senha da conta.',
                  style: theme.textTheme.titleLarge,
                ),
                SizedBox(height: sizes.md),
                Text(
                  'Aprove somente se você reconhece e autoriza este pedido. '
                  'A resposta será compartilhada com o idoso.',
                  style: theme.textTheme.bodyLarge,
                ),
                SizedBox(height: sizes.md),
                Text(statusMessage, style: theme.textTheme.bodyMedium),
                const Spacer(),
                if (isPending) ...[
                  ButtonWidget(
                    label: _isResponding
                        ? 'Aguarde...'
                        : 'Aprovar troca de senha',
                    variant: ButtonVariant.primary,
                    onPressed: _isResponding ? null : () => _respond(true),
                  ),
                  SizedBox(height: sizes.md),
                  ButtonWidget(
                    label: 'Recusar solicitação',
                    variant: ButtonVariant.outlined,
                    onPressed: _isResponding ? null : () => _respond(false),
                  ),
                ] else if (request.status == 'approved' && isApprover) ...[
                  if (request.deliveryForwardedToElder)
                    Text(
                      'O link já foi encaminhado à sessão privada do idoso.',
                      style: theme.textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    )
                  else if (request.linkDeliveredToApprover)
                    ButtonWidget(
                      label: _isForwarding
                          ? 'Encaminhando...'
                          : 'Encaminhar link ao idoso',
                      variant: ButtonVariant.primary,
                      onPressed: request.isExpired || _isForwarding
                          ? null
                          : _forwardLink,
                    )
                  else
                    Text(
                      'A equipe de suporte ainda não disponibilizou o link.',
                      style: theme.textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}
