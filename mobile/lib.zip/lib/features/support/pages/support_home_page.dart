import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/app_sizes.dart';
import '../../../core/routes/route_names.dart';
import '../../../core/services/elder_recovery_request_service.dart';
import '../../auth/models/account_type.dart';
import '../../auth/models/elder_recovery_request.dart';
import '../../auth/providers/current_user_provider.dart';
import '../providers/support_recovery_requests_provider.dart';

class SupportHomePage extends ConsumerStatefulWidget {
  const SupportHomePage({super.key});

  @override
  ConsumerState<SupportHomePage> createState() => _SupportHomePageState();
}

class _SupportHomePageState extends ConsumerState<SupportHomePage> {
  final Set<String> _deliveringLinkRequestIds = {};
  final Set<String> _requestingReplacementEmailIds = {};

  Future<void> _signOut() async {
    await ref.read(currentUserProvider.notifier).signOut();
    if (mounted) context.go(RouteNames.onboarding);
  }

  Future<void> _copyElderUid(String elderUid) async {
    await Clipboard.setData(ClipboardData(text: elderUid));
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('UID copiado.')));
  }

  Future<bool> _deliverResetLink(
    ElderRecoveryRequest request,
    String resetLink,
  ) async {
    final approvedByUid = request.approvedByUid;
    if (approvedByUid == null) return false;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Disponibilizar link'),
        content: Text(
          'O link ficará disponível somente para o responsável que aprovou '
          'este pedido:\n\n'
          '$approvedByUid (${_accountTypeLabel(request.approvedByType)}).\n\n'
          'Confirme que este é o link de redefinição correto.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Voltar'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Disponibilizar link'),
          ),
        ],
      ),
    );
    if (confirmed != true) return false;

    setState(() => _deliveringLinkRequestIds.add(request.id));
    try {
      await ElderRecoveryRequestService.instance.deliverResetLink(
        requestId: request.id,
        resetLink: resetLink,
      );
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link disponibilizado ao responsável.')),
      );
      return true;
    } on StateError catch (error) {
      if (!mounted) return false;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(error.message.toString())));
    } on FirebaseException {
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Não foi possível disponibilizar o link. Tente novamente.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _deliveringLinkRequestIds.remove(request.id));
      }
    }
    return false;
  }

  Future<bool> _requestResetEmail(
    ElderRecoveryRequest request,
    String elderCode,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Solicitar e-mail de redefinição'),
        content: const Text(
          'O Firebase enviará um e-mail de redefinição para o endereço '
          'associado ao código ELD. O pedido só será marcado como enviado '
          'depois que o Firebase aceitar a solicitação. Novos envios exigem '
          'um intervalo mínimo de cinco minutos.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Voltar'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Solicitar e-mail'),
          ),
        ],
      ),
    );
    if (confirmed != true) return false;

    setState(() => _requestingReplacementEmailIds.add(request.id));
    try {
      await ElderRecoveryRequestService.instance.requestResetEmail(
        requestId: request.id,
        elderCode: elderCode,
      );
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Solicitação enviada ao Firebase. Confira a caixa de suporte.',
          ),
        ),
      );
      return true;
    } on StateError catch (error) {
      if (!mounted) return false;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(error.message.toString())));
    } on FirebaseAuthException {
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Não foi possível solicitar outro e-mail ao Firebase.'),
        ),
      );
    } on FirebaseException {
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Não foi possível solicitar outro e-mail. Tente novamente.',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _requestingReplacementEmailIds.remove(request.id));
      }
    }
    return false;
  }

  String _accountTypeLabel(String? accountType) {
    return switch (accountType) {
      'family' => 'familiar',
      'caregiver' => 'cuidador',
      _ => 'responsável',
    };
  }

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(currentUserProvider);
    final theme = Theme.of(context);
    final sizes = context.appSizes;

    return session.when(
      loading: () =>
          const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (error, stackTrace) => Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.all(sizes.lg),
            child: Text(
              'Não foi possível validar a conta de suporte.',
              style: theme.textTheme.bodyLarge,
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
      data: (user) {
        if (user?.accountType != AccountType.support) {
          return Scaffold(
            body: Center(
              child: FilledButton(
                onPressed: () => context.go(RouteNames.onboarding),
                child: const Text('Voltar ao início'),
              ),
            ),
          );
        }

        return Scaffold(
          appBar: AppBar(
            title: const Text('Suporte Conviva'),
            actions: [
              IconButton(
                tooltip: 'Sair da conta',
                onPressed: _signOut,
                icon: const Icon(Icons.logout_rounded),
              ),
            ],
          ),
          body: ListView(
            padding: EdgeInsets.all(sizes.lg),
            children: [
              Card(
                child: Padding(
                  padding: EdgeInsets.all(sizes.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Como atender uma solicitação',
                        style: theme.textTheme.titleMedium,
                      ),
                      SizedBox(height: sizes.sm),
                      const Text(
                        'Cole abaixo o link de redefinição obtido pelo processo '
                        'autorizado do Firebase. O link será enviado apenas ao '
                        'responsável que aprovou e poderá ser encaminhado ao '
                        'idoso pelo app. Se estiver vencido ou inválido, solicite '
                        'outro e-mail enquanto o pedido ainda estiver válido. '
                        'A conta de suporte não concede acesso ao Console.',
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: sizes.lg),
              Text('Pedidos aprovados', style: theme.textTheme.titleLarge),
              SizedBox(height: sizes.sm),
              _buildRequestList(sizes),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRequestList(AppSizesTheme sizes) {
    final requests = ref.watch(supportRecoveryRequestsProvider);

    return requests.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (error, stackTrace) =>
          const Text('Não foi possível carregar os pedidos aprovados.'),
      data: (items) {
        if (items.isEmpty) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Text('Não há pedidos aprovados aguardando atendimento.'),
          );
        }

        return Column(
          children: [
            for (final request in items) ...[
              _SupportRequestCard(
                key: ValueKey(request.id),
                request: request,
                isDeliveringLink: _deliveringLinkRequestIds.contains(
                  request.id,
                ),
                isRequestingReplacementEmail: _requestingReplacementEmailIds
                    .contains(request.id),
                onCopyUid: () => _copyElderUid(request.elderUid),
                onDeliverLink: (link) => _deliverResetLink(request, link),
                onRequestReplacementEmail: (code) =>
                    _requestResetEmail(request, code),
              ),
              SizedBox(height: sizes.md),
            ],
          ],
        );
      },
    );
  }
}

class _SupportRequestCard extends StatefulWidget {
  const _SupportRequestCard({
    super.key,
    required this.request,
    required this.isDeliveringLink,
    required this.isRequestingReplacementEmail,
    required this.onCopyUid,
    required this.onDeliverLink,
    required this.onRequestReplacementEmail,
  });

  final ElderRecoveryRequest request;
  final bool isDeliveringLink;
  final bool isRequestingReplacementEmail;
  final VoidCallback onCopyUid;
  final Future<bool> Function(String link) onDeliverLink;
  final Future<bool> Function(String code) onRequestReplacementEmail;

  @override
  State<_SupportRequestCard> createState() => _SupportRequestCardState();
}

class _SupportRequestCardState extends State<_SupportRequestCard> {
  final _resetLinkController = TextEditingController();
  final _elderCodeController = TextEditingController();

  @override
  void dispose() {
    _resetLinkController.dispose();
    _elderCodeController.dispose();
    super.dispose();
  }

  Future<void> _submitResetLink() async {
    final saved = await widget.onDeliverLink(_resetLinkController.text);
    if (saved && mounted) _resetLinkController.clear();
  }

  Future<void> _submitReplacementEmailRequest() async {
    final requested = await widget.onRequestReplacementEmail(
      _elderCodeController.text,
    );
    if (requested && mounted) _elderCodeController.clear();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final sizes = context.appSizes;
    final request = widget.request;
    final isExpired = request.isExpired;
    final canDeliverLink =
        !isExpired &&
        !request.linkDeliveredToApprover &&
        request.approvedByUid != null &&
        !widget.isDeliveringLink;

    return Card(
      child: Padding(
        padding: EdgeInsets.all(sizes.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isExpired ? 'Pedido expirado' : 'Aprovado para atendimento',
              style: theme.textTheme.titleMedium,
            ),
            SizedBox(height: sizes.sm),
            Text('UID do idoso:'),
            SelectableText(request.elderUid),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: widget.onCopyUid,
                icon: const Icon(Icons.copy_rounded),
                label: const Text('Copiar UID'),
              ),
            ),
            SizedBox(height: sizes.sm),
            Text(
              'Responsável que aprovou: '
              '${request.approvedByUid ?? 'indisponível'} '
              '(${switch (request.approvedByType) {
                'family' => 'familiar',
                'caregiver' => 'cuidador',
                _ => 'tipo desconhecido',
              }})',
            ),
            Text(
              isExpired
                  ? 'O prazo de 24 horas terminou. Não conclua este pedido.'
                  : 'Prazo até ${_formatDate(request.expiresAt)}',
              style: theme.textTheme.bodySmall?.copyWith(
                color: isExpired ? theme.colorScheme.error : null,
              ),
            ),
            SizedBox(height: sizes.md),
            if (request.linkDeliveredToApprover) ...[
              Text(
                request.deliveryForwardedToElder
                    ? 'O link foi encaminhado ao idoso.'
                    : 'O link já está disponível para o responsável.',
                style: theme.textTheme.bodyMedium,
              ),
              SizedBox(height: sizes.md),
            ] else ...[
              TextField(
                controller: _resetLinkController,
                enabled: canDeliverLink,
                keyboardType: TextInputType.url,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Link de redefinição do Firebase',
                  hintText: 'https://...',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: sizes.sm),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: canDeliverLink ? _submitResetLink : null,
                  icon: widget.isDeliveringLink
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.lock_outline_rounded),
                  label: Text(
                    widget.isDeliveringLink
                        ? 'Disponibilizando...'
                        : 'Disponibilizar link ao responsável',
                  ),
                ),
              ),
              SizedBox(height: sizes.md),
            ],
            if (!isExpired) ...[
              if (request.resetEmailRequested)
                Padding(
                  padding: EdgeInsets.only(bottom: sizes.sm),
                  child: Text(
                    'O Firebase aceitou a solicitação de envio. Confira a caixa '
                    'de suporte; isso não confirma a entrega do e-mail.',
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
              TextField(
                controller: _elderCodeController,
                enabled: !isExpired && !widget.isRequestingReplacementEmail,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'Código ELD do idoso',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: sizes.sm),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: isExpired || widget.isRequestingReplacementEmail
                      ? null
                      : _submitReplacementEmailRequest,
                  icon: widget.isRequestingReplacementEmail
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.mark_email_unread_outlined),
                  label: Text(
                    widget.isRequestingReplacementEmail
                        ? 'Solicitando...'
                        : 'Solicitar e-mail de redefinição',
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final local = date.toLocal();
    final day = local.day.toString().padLeft(2, '0');
    final month = local.month.toString().padLeft(2, '0');
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$day/$month/${local.year} às $hour:$minute';
  }
}
