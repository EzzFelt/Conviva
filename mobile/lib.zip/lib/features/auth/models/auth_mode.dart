enum AuthMode {
  login,
  register,
}