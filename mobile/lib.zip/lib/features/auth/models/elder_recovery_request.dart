import 'package:cloud_firestore/cloud_firestore.dart';

class ElderRecoveryRequest {
  const ElderRecoveryRequest({
    required this.id,
    required this.elderUid,
    required this.institutionId,
    required this.familyUid,
    required this.caregiverUid,
    required this.requesterUid,
    required this.status,
    required this.createdAt,
    this.approvedByUid,
    this.approvedByType,
    this.linkDeliveredToApprover = false,
    this.deliveryForwardedToElder = false,
    this.resetEmailRequested = false,
    this.elderName,
  });

  final String id;
  final String elderUid;
  final String institutionId;
  final String familyUid;
  final String caregiverUid;
  final String requesterUid;
  final String status;
  final DateTime createdAt;
  final String? approvedByUid;
  final String? approvedByType;
  final bool linkDeliveredToApprover;
  final bool deliveryForwardedToElder;
  final bool resetEmailRequested;
  final String? elderName;

  DateTime get expiresAt => createdAt.add(const Duration(hours: 24));

  bool get isExpired =>
      status == 'pending' && !DateTime.now().isBefore(expiresAt);

  factory ElderRecoveryRequest.fromMap({
    required String id,
    required Map<String, dynamic> data,
  }) {
    final createdAt = data['createdAt'];
    if (createdAt is! Timestamp) {
      throw const FormatException('Data do pedido inválida.');
    }

    String requiredString(String key) {
      final value = data[key];
      if (value is! String || value.isEmpty) {
        throw FormatException('Campo $key inválido no pedido.');
      }
      return value;
    }

    final status = requiredString('status');
    if (!{'pending', 'approved', 'rejected', 'completed'}.contains(status)) {
      throw const FormatException('Status do pedido inválido.');
    }

    final familyUid = requiredString('familyUid');
    final caregiverUid = requiredString('caregiverUid');
    final approvedByUid =
        data['approvedByUid']?.toString() ??
        (status == 'approved' ? data['respondedBy']?.toString() : null);
    final approvedByType =
        data['approvedByType']?.toString() ??
        (approvedByUid == familyUid
            ? 'family'
            : approvedByUid == caregiverUid
            ? 'caregiver'
            : null);
    if (approvedByType != null &&
        !{'family', 'caregiver'}.contains(approvedByType)) {
      throw const FormatException('Tipo de aprovador inválido.');
    }

    return ElderRecoveryRequest(
      id: id,
      elderUid: requiredString('elderUid'),
      institutionId: requiredString('institutionId'),
      familyUid: familyUid,
      caregiverUid: caregiverUid,
      requesterUid: requiredString('requesterUid'),
      status: status,
      createdAt: createdAt.toDate(),
      approvedByUid: approvedByUid,
      approvedByType: approvedByType,
      linkDeliveredToApprover: data['linkDeliveredToApprover'] == true,
      deliveryForwardedToElder: data['deliveryForwardedToElder'] == true,
      resetEmailRequested: data['resetEmailRequested'] == true,
      elderName: data['elderName']?.toString(),
    );
  }

  ElderRecoveryRequest copyWith({String? elderName}) {
    return ElderRecoveryRequest(
      id: id,
      elderUid: elderUid,
      institutionId: institutionId,
      familyUid: familyUid,
      caregiverUid: caregiverUid,
      requesterUid: requesterUid,
      status: status,
      createdAt: createdAt,
      approvedByUid: approvedByUid,
      approvedByType: approvedByType,
      linkDeliveredToApprover: linkDeliveredToApprover,
      deliveryForwardedToElder: deliveryForwardedToElder,
      resetEmailRequested: resetEmailRequested,
      elderName: elderName ?? this.elderName,
    );
  }
}
